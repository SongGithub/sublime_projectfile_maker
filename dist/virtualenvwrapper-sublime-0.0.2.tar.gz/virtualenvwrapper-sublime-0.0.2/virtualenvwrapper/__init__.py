"""virtualenvwrapper.sublime_project"""
__import__('pkg_resources').declare_namespace(__name__)
